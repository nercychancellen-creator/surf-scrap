# surf-scrap 🌊

`surf-scrap` is a Python library that scrapes surf forecast data from surf-report.com
and exports it into a CSV file.

The library can be used either:
- as a **Python package**
- or as a **command-line tool (CLI)**

---

## 🚀 Installation

Use pip to install the package:

```bash
pip install surf-scrap
```


## Usage (as a library)

```python 
from surf_scrap import extract_and_save

url = "https://www.surf-report.com/meteo-surf/lacanau-s1043.html"
output_file = "surf_data.csv"

extract_and_save(url, output_file)

```
This will generate a CSV file containing:

day and hour

wave size

wind speed

wind direction

## 🖥️ Command Line Interface (CLI)
After installation, you can also run the scraper directly from the terminal:
```bash
surf-scrap "https://www.surf-report.com/meteo-surf/lacanau-s1043.html" surf_data.csv
```
This command produces the same CSV output as the Python usage.

## 🧩 Dependencies

The following dependencies are automatically installed with the package:

requests

beautifulsoup4

pandas

## ⚠️ Disclaimer

This project is intended for educational and personal use only.
Please respect the terms of service of the scraped website.